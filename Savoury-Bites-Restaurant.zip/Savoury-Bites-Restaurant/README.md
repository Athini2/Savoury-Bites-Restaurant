# Savoury Bites Restaurant Website

This is a complete restaurant website for "Savoury Bites" with responsive design, dark mode toggle, interactive features, and all the requirements specified in the assessment.

## Project Structure

```
savoury-bites/
├── index.html          # Home page
├── menu.html           # Menu page with categorized items
├── specials.html       # Specials and promotions page
├── reservation.html    # Reservation and contact page
├── css/
│   └── styles.css      # Main stylesheet with all CSS rules
├── js/
│   └── script.js       # JavaScript functionality
└── README.md           # This file
```

## Features Implemented

1. **Responsive Design**: Works on mobile, tablet, and desktop devices
2. **Dark Mode Toggle**: Persistent dark/light mode across all pages
3. **Interactive Elements**:
   - Image slider for featured dishes (auto-rotating)
   - Form validation for reservations
   - Modal popups for special offers
   - Dynamic greeting based on time of day
4. **Consistent Styling**: Unified design across all pages
5. **Cross-page Navigation**: Sticky navigation with active page highlighting

## Pages

### Home Page (index.html)
- Hero banner with welcoming image
- Restaurant story section
- Navigation menu with active state
- Footer with contact information

### Menu Page (menu.html)
- Four categories: Starters, Mains, Desserts, Drinks
- Each category has at least three items with name, description, and price
- Styled card layout for menu items
- Call-to-action for reservations

### Specials Page (specials.html)
- Three special offers with images, descriptions, and badges
- Chef's featured dishes slider (auto-rotating every 5 seconds)
- Modal popups with detailed special offer information
- Call-to-action for reservations

### Reservation Page (reservation.html)
- Form with validation for:
  - Name (required)
  - Email (required, format validation)
  - Date (required, future date validation)
  - Time (required)
  - Number of guests (required)
- Contact information section
- Embedded Google Maps location

## Technical Implementation

### CSS Features
- CSS variables for consistent theming
- Flexbox and Grid for responsive layouts
- Media queries for different screen sizes
- Smooth transitions and hover effects
- Dark mode support with CSS custom properties

### JavaScript Features
- Dark mode toggle with localStorage persistence
- Mobile menu toggle for responsive navigation
- Dynamic greeting based on time of day
- Form validation for reservation page
- Auto-rotating image slider for featured dishes
- Modal popups for special offers
- Smooth scrolling navigation

## How to Use

1. Download the entire folder
2. Open `index.html` in a web browser to start
3. Navigate between pages using the menu
4. Toggle dark mode using the button in the top-right corner
5. Interact with form elements and sliders

## Browser Compatibility

This website works in all modern browsers that support:
- CSS3 (Flexbox, Grid, Transitions)
- ES6 JavaScript
- localStorage API

## Credits

Designed by Athini Zoleka
© 2025 Savoury Bites. All rights reserved.