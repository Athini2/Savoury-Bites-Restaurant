# reservation.html - Line-by-Line Explanation

This file is the reservation page for the Savoury Bites restaurant website. It includes a booking form and contact information.

## Document Declaration and Head Section

```html
<!DOCTYPE html>
```
Declares the document as HTML5, telling the browser which version of HTML to use.

```html
<html lang="en">
```
Opens the HTML document and sets the language to English for accessibility and SEO.

```html
<head>
```
Opens the head section where we put metadata and links to external files.

```html
<meta charset="UTF-8">
```
Sets character encoding to UTF-8 to support all characters and symbols.

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```
Makes the website responsive by setting the viewport to match device width.

```html
<meta name="description" content="Savoury Bites Reservations - Book your table online or contact us for inquiries">
```
Provides a description for search engines (SEO optimization).

```html
<meta name="keywords" content="restaurant reservation, book table, Savoury Bites contact, Cape Town dining">
```
Lists keywords related to the website for search engines.

```html
<title>Reservations & Contact | Savoury Bites</title>
```
Sets the title that appears in the browser tab.

```html
<link rel="stylesheet" href="css/styles.css">
```
Links the external CSS stylesheet to style the webpage.

```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```
Links Font Awesome library for icons (menu icons, social media icons, etc.).

```html
</head>
```
Closes the head section.

## Body Section

```html
<body>
```
Opens the body section where all visible content goes.

```html
<button id="darkModeToggle" class="dark-mode-btn" aria-label="Toggle Dark Mode">
```
Creates a button for dark mode toggle with unique ID for JavaScript control.

```html
<i class="fas fa-moon"></i>
```
Adds a moon icon from Font Awesome inside the dark mode button.

```html
</button>
```
Closes the button element.

```html
<nav class="navbar">
```
Creates a navigation element with class navbar for styling.

```html
<div class="container">
```
Creates a container div to center and constrain the navigation content.

```html
<div class="logo">
```
Creates a div to hold the restaurant logo and name.

```html
<i class="fas fa-utensils"></i>
```
Adds a utensils icon (fork and knife) as part of the logo.

```html
<h1>Savoury Bites</h1>
```
Creates the main heading with the restaurant name.

```html
</div>
```
Closes the logo div.

```html
<ul class="nav-menu">
```
Creates an unordered list for navigation menu items.

```html
<li><a href="index.html">Home</a></li>
```
Creates menu item linking to homepage.

```html
<li><a href="menu.html">Menu</a></li>
```
Creates menu item linking to the menu page.

```html
<li><a href="specials.html">Specials</a></li>
```
Creates menu item linking to the specials page.

```html
<li><a href="reservation.html" class="active">Reservations</a></li>
```
Creates menu item linking to the reservation page with active class to highlight current page.

```html
</ul>
```
Closes the navigation menu list.

```html
<div class="hamburger">
```
Creates a div for the mobile hamburger menu icon.

```html
<span></span>
```
Creates first line of the hamburger icon.

```html
<span></span>
```
Creates second line of the hamburger icon.

```html
<span></span>
```
Creates third line of the hamburger icon.

```html
</div>
```
Closes the hamburger div.

```html
</div>
```
Closes the container div.

```html
</nav>
```
Closes the navigation element.

```html
<section class="hero reservation-hero">
```
Creates a section element with class hero for the reservation page banner area.

```html
<div class="hero-content">
```
Creates a div to hold the hero section content.

```html
<h2>Make a Reservation</h2>
```
Creates a heading for the reservation page hero section.

```html
<p>Book your table and enjoy an exceptional dining experience</p>
```
Creates a paragraph with the reservation page tagline.

```html
</div>
```
Closes the hero-content div.

```html
</section>
```
Closes the hero section.

```html
<section class="reservation-section">
```
Creates a section for the reservation content.

```html
<div class="container">
```
Creates a container to center the reservation content.

```html
<div class="reservation-content">
```
Creates a div to hold both the reservation form and contact information.

## Reservation Form

```html
<div class="form-container">
```
Creates a div for the reservation form container.

```html
<h2 class="section-title">Book Your Table</h2>
```
Creates a heading for the form section.

```html
<form id="reservationForm">
```
Creates a form element with ID for JavaScript interaction.

### Name Field

```html
<div class="form-group">
```
Creates a div for the name form group.

```html
<label for="name">Full Name *</label>
```
Creates a label for the name input (asterisk indicates required field).

```html
<input type="text" id="name" name="name" required>
```
Creates a text input for the customer's name.

```html
</div>
```
Closes the form-group div.

### Email Field

```html
<div class="form-group">
```
Creates a div for the email form group.

```html
<label for="email">Email Address *</label>
```
Creates a label for the email input (asterisk indicates required field).

```html
<input type="email" id="email" name="email" required>
```
Creates an email input for the customer's email address.

```html
</div>
```
Closes the form-group div.

### Date Field

```html
<div class="form-group">
```
Creates a div for the date form group.

```html
<label for="date">Date *</label>
```
Creates a label for the date input (asterisk indicates required field).

```html
<input type="date" id="date" name="date" required>
```
Creates a date input for the reservation date.

```html
</div>
```
Closes the form-group div.

### Time Field

```html
<div class="form-group">
```
Creates a div for the time form group.

```html
<label for="time">Time *</label>
```
Creates a label for the time input (asterisk indicates required field).

```html
<input type="time" id="time" name="time" required>
```
Creates a time input for the reservation time.

```html
</div>
```
Closes the form-group div.

### Number of Guests Field

```html
<div class="form-group">
```
Creates a div for the guests form group.

```html
<label for="guests">Number of Guests *</label>
```
Creates a label for the guests select (asterisk indicates required field).

```html
<select id="guests" name="guests" required>
```
Creates a select dropdown for the number of guests.

```html
<option value="">Select number of guests</option>
```
Creates a default option prompting the user to select.

```html
<option value="1">1 Guest</option>
```
Creates an option for 1 guest.

(Additional options for 2-10 guests and 10+ guests)

```html
</select>
```
Closes the select element.

```html
</div>
```
Closes the form-group div.

### Special Requests Field

```html
<div class="form-group">
```
Creates a div for the special requests form group.

```html
<label for="specialRequests">Special Requests</label>
```
Creates a label for the special requests textarea.

```html
<textarea id="specialRequests" name="specialRequests" rows="4" placeholder="Any special requests or dietary requirements?"></textarea>
```
Creates a textarea for special requests or dietary requirements.

```html
</div>
```
Closes the form-group div.

### Submit Button

```html
<button type="submit" class="btn btn-primary">Submit Reservation</button>
```
Creates a submit button for the form.

```html
</form>
```
Closes the form element.

### Confirmation Message

```html
<div id="confirmationMessage" class="confirmation-message" style="display: none;">
```
Creates a div for the confirmation message (initially hidden with inline style).

```html
<h3>Reservation Confirmed!</h3>
```
Creates a heading for the confirmation message.

```html
<p>Thank you for your reservation. We've sent a confirmation to your email.</p>
```
Creates a paragraph confirming the reservation.

```html
<p>We look forward to serving you at Savoury Bites!</p>
```
Creates a closing paragraph for the confirmation message.

```html
</div>
```
Closes the confirmation-message div.

```html
</div>
```
Closes the form-container div.

## Contact Information

```html
<div class="contact-info">
```
Creates a div for the contact information section.

```html
<h2 class="section-title">Contact Information</h2>
```
Creates a heading for the contact information section.

### Address

```html
<div class="contact-details">
```
Creates a div for the contact details.

```html
<div class="contact-item">
```
Creates a div for the address contact item.

```html
<i class="fas fa-map-marker-alt contact-icon"></i>
```
Creates an icon for the address.

```html
<div>
```
Creates a div for the address content.

```html
<h3>Address</h3>
```
Creates a heading for the address section.

```html
<p>123 Food Street, Cape Town, 8001</p>
```
Creates a paragraph with the restaurant address.

```html
</div>
```
Closes the address content div.

```html
</div>
```
Closes the contact-item div.

### Phone

```html
<div class="contact-item">
```
Creates a div for the phone contact item.

```html
<i class="fas fa-phone contact-icon"></i>
```
Creates an icon for the phone number.

```html
<div>
```
Creates a div for the phone content.

```html
<h3>Phone</h3>
```
Creates a heading for the phone section.

```html
<p>+27 21 123 4567</p>
```
Creates a paragraph with the restaurant phone number.

```html
</div>
```
Closes the phone content div.

```html
</div>
```
Closes the contact-item div.

### Email

```html
<div class="contact-item">
```
Creates a div for the email contact item.

```html
<i class="fas fa-envelope contact-icon"></i>
```
Creates an icon for the email address.

```html
<div>
```
Creates a div for the email content.

```html
<h3>Email</h3>
```
Creates a heading for the email section.

```html
<p>info@savourybites.co.za</p>
```
Creates a paragraph with the restaurant email address.

```html
</div>
```
Closes the email content div.

```html
</div>
```
Closes the contact-item div.

### Opening Hours

```html
<div class="contact-item">
```
Creates a div for the opening hours contact item.

```html
<i class="fas fa-clock contact-icon"></i>
```
Creates an icon for the opening hours.

```html
<div>
```
Creates a div for the opening hours content.

```html
<h3>Opening Hours</h3>
```
Creates a heading for the opening hours section.

```html
<p>Monday - Friday: 11:00 AM - 10:00 PM</p>
```
Creates a paragraph with weekday hours.

```html
<p>Saturday - Sunday: 10:00 AM - 11:00 PM</p>
```
Creates a paragraph with weekend hours.

```html
</div>
```
Closes the opening hours content div.

```html
</div>
```
Closes the contact-item div.

```html
</div>
```
Closes the contact-details div.

## Map Section

```html
<div class="map-container">
```
Creates a div for the map container.

```html
<h3>Find Us</h3>
```
Creates a heading for the map section.

```html
<div class="map-placeholder">
```
Creates a div for the map placeholder.

```html
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24157.073210238823!2d28.047305!3d-26.204103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950b1d6f4328d5%3A0x2b7ecfcf3f5f5f5!2sCapeTown%2C%20South%20Africa!5e0!3m2!1sen!2sza!4v1706703438497!5m2!1sen!2sza" 
    width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
```
Creates an iframe with embedded Google Maps showing the restaurant location.

```html
</div>
```
Closes the map-placeholder div.

```html
</div>
```
Closes the map-container div.

```html
</div>
```
Closes the contact-info div.

```html
</div>
```
Closes the reservation-content div.

```html
</div>
```
Closes the container div.

```html
</section>
```
Closes the reservation-section.

```html
<footer class="footer">
```
Creates a footer element with class footer.

(Contains the same footer structure as index.html)

```html
<script src="js/script.js"></script>
```
Links the external JavaScript file for interactivity.

```html
</body>
```
Closes the body section.

```html
</html>
```
Closes the HTML document.