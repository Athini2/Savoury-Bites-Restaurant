// script.js - JavaScript functionality for Savoury Bites website

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Dark mode toggle functionality
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;

    // Check for saved theme preference or respect OS preference
    const savedTheme = localStorage.getItem('theme');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');

    if (savedTheme === 'dark' || (!savedTheme && prefersDarkScheme.matches)) {
        body.setAttribute('data-theme', 'dark');
        if (darkModeToggle) {
            darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
    }

    // Toggle dark mode
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', function() {
            const currentTheme = body.getAttribute('data-theme');

            if (currentTheme === 'dark') {
                body.removeAttribute('data-theme');
                localStorage.setItem('theme', 'light');
                darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                body.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
                darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            }
        });
    }

    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }

    // Dynamic greeting based on time of day
    const greetingElement = document.getElementById('greeting');
    if (greetingElement) {
        const hours = new Date().getHours();
        let greeting;

        if (hours < 12) {
            greeting = "Good Morning! Welcome to Savoury Bites";
        } else if (hours < 18) {
            greeting = "Good Afternoon! Welcome to Savoury Bites";
        } else {
            greeting = "Good Evening! Welcome to Savoury Bites";
        }

        greetingElement.textContent = greeting;
    }

    // Form validation for reservation page
    const reservationForm = document.getElementById('reservationForm');
    if (reservationForm) {
        reservationForm.addEventListener('submit', function(e) {
            e.preventDefault();

            // Get form values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const date = document.getElementById('date').value;
            const time = document.getElementById('time').value;
            const guests = document.getElementById('guests').value;

            // Validation
            if (!name || !email || !date || !time || !guests) {
                alert('Please fill in all required fields.');
                return;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address.');
                return;
            }

            // Date validation (can't book in the past)
            const selectedDate = new Date(date);
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            if (selectedDate < today) {
                alert('Please select a future date for your reservation.');
                return;
            }

            // If all validations pass, show confirmation
            document.getElementById('reservationForm').style.display = 'none';
            document.getElementById('confirmationMessage').style.display = 'block';

            // In a real application, you would send the data to a server here
            console.log('Reservation submitted:', { name, email, date, time, guests });
        });
    }

    // Image slider for featured dishes (Specials page)
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');

    if (slider && slides.length > 0) {
        let currentSlide = 0;
        const slideCount = slides.length;
        let slideInterval;

        // Function to update slider position
        function updateSlider() {
            slider.style.transform = `translateX(-${currentSlide * 100}%)`;
        }

        // Next button functionality
        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                currentSlide = (currentSlide + 1) % slideCount;
                updateSlider();
                resetInterval(); // Reset interval when manually navigating
            });
        }

        // Previous button functionality
        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                currentSlide = (currentSlide - 1 + slideCount) % slideCount;
                updateSlider();
                resetInterval(); // Reset interval when manually navigating
            });
        }

        // Auto-advance slider every 5 seconds
        function startSlider() {
            slideInterval = setInterval(() => {
                currentSlide = (currentSlide + 1) % slideCount;
                updateSlider();
            }, 5000);
        }

        // Reset interval (when manually navigating)
        function resetInterval() {
            clearInterval(slideInterval);
            startSlider();
        }

        // Start the automatic sliding
        startSlider();
    }

    // Specials modal functionality
    const modalTriggers = document.querySelectorAll('.special-modal-trigger');
    const modal = document.getElementById('specialModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const closeBtn = document.querySelector('.close');

    // Special details data
    const specialDetails = {
        'Happy Hour': {
            title: 'Happy Hour Special',
            description: 'Join us for Happy Hour Monday to Sunday from 4pm to 6pm. Enjoy 20% off all drinks and selected appetizers. This is the perfect time to unwind after work or start your evening with friends. Our signature cocktails, craft beers, and wine are all included in this special offer. Try our famous truffle arancini or calamari fritti at a reduced price!',
            terms: 'Valid only during Happy Hour (4:00 PM - 6:00 PM). Cannot be combined with other offers. Valid for dine-in only.'
        },
        'Birthday Celebration': {
            title: 'Birthday Celebration',
            description: 'Celebrate your special day with us! Get a complimentary dessert and 15% off your entire meal when you dine with us on your birthday. Make your birthday memorable with our chef\'s special menu and a personalized dessert with candle. We\'ll even serenade you with our birthday song!',
            terms: 'Valid for the birthday person with valid ID. Advance reservation required. Cannot be combined with other offers. Valid for dine-in only.'
        },
        'Group Dining': {
            title: 'Group Dining Special',
            description: 'Bring a group of 6 or more and receive a complimentary bottle of wine and 10% off your entire bill. Perfect for celebrations, corporate events, or family gatherings. Our private dining area can accommodate your group comfortably with personalized service.',
            terms: 'Valid for groups of 6 or more. Complimentary wine selection varies based on availability. Cannot be combined with other offers. Advance reservation required.'
        }
    };

    // Open modal with specific content
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const specialName = this.getAttribute('data-special');
            const details = specialDetails[specialName];

            if (details) {
                modalTitle.textContent = details.title;
                modalBody.innerHTML = `
                    <p>${details.description}</p>
                    <div style="background: #f8f9fa; padding: 15px; border-left: 4px solid var(--primary-color); margin: 20px 0;">
                        <h4>Terms & Conditions</h4>
                        <p>${details.terms}</p>
                    </div>
                `;

                if (modal) {
                    modal.style.display = 'block';
                }
            }
        });
    });

    // Close modal
    if (closeBtn && modal) {
        closeBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });

        // Close modal when clicking outside of it
        window.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId !== '#' && document.querySelector(targetId)) {
                e.preventDefault();
                const targetElement = document.querySelector(targetId);
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Additional utility functions

// Function to validate email format
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Function to validate phone number format (South African format)
function validatePhone(phone) {
    const re = /^(\+27|27|0)[6-8][0-9]{8}$/;
    return re.test(phone);
}

// Function to format currency (for menu prices)
function formatCurrency(amount) {
    return 'R' + amount.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// Function to get current date in YYYY-MM-DD format
function getCurrentDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Set min date for reservation form to today
document.addEventListener('DOMContentLoaded', function() {
    const dateInput = document.getElementById('date');
    if (dateInput) {
        dateInput.min = getCurrentDate();
    }
});