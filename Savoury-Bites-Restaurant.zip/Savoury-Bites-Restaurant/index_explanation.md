# index.html - Line-by-Line Explanation

This file is the homepage for the Savoury Bites restaurant website. It includes all necessary meta tags, links to stylesheets, and the complete HTML structure for the home page.

## Document Declaration and Head Section

```html
<!DOCTYPE html>
```
Declares the document as HTML5, telling the browser which version of HTML to use.

```html
<html lang="en">
```
Opens the HTML document and sets the language to English for accessibility and SEO.

```html
<head>
```
s.

```htmlOpens the head section where we put metadata and links to external file
<meta charset="UTF-8">
```
Sets character encoding to UTF-8 to support all characters and symbols.

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```
Makes the website responsive by setting the viewport to match device width.

```html
<meta name="description" content="Savoury Bites - Experience fine dining with our exquisite menu and exceptional service">
```
Provides a description for search engines (SEO optimization).

```html
<meta name="keywords" content="restaurant, fine dining, food, Cape Town, Savoury Bites">
```
Lists keywords related to the website for search engines.

```html
<title>Savoury Bites - Home | Fine Dining Restaurant</title>
```
Sets the title that appears in the browser tab.

```html
<link rel="stylesheet" href="css/styles.css">
```
Links the external CSS stylesheet to style the webpage.

```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```
Links Font Awesome library for icons (menu icons, social media icons, etc.).


```html
</head>
```
Closes the head section.

## Body Section

```html
<body>
```
Opens the body section where all visible content goes.

```html
<button id="darkModeToggle" class="dark-mode-btn" aria-label="Toggle Dark Mode">
```
Creates a button for dark mode toggle with unique ID for JavaScript control.

```html
<i class="fas fa-moon"></i>
```
Adds a moon icon from Font Awesome inside the dark mode button.

```html
</button>
```
Closes the button element.

```html
<nav class="navbar">
```
Creates a navigation element with class navbar for styling.

```html
<div class="container">
```
Creates a container div to center and constrain the navigation content.

```html
<div class="logo">
```
Creates a div to hold the restaurant logo and name.

```html
<i class="fas fa-utensils"></i>
```
Adds a utensils icon (fork and knife) as part of the logo.

```html
<h1>Savoury Bites</h1>
```
Creates the main heading with the restaurant name.

```html
</div>
```
Closes the logo div.

```html
<ul class="nav-menu">
```
Creates an unordered list for navigation menu items.

```html
<li><a href="index.html" class="active">Home</a></li>
```
Creates first menu item linking to homepage with active class to highlight current page.

```html
<li><a href="menu.html">Menu</a></li>
```
Creates menu item linking to the menu page.

```html
<li><a href="specials.html">Specials</a></li>
```
Creates menu item linking to the specials page.

```html
<li><a href="reservation.html">Reservations</a></li>
```
Creates menu item linking to the reservation page.

```html
</ul>
```
Closes the navigation menu list.

```html
<div class="hamburger">
```
Creates a div for the mobile hamburger menu icon.

```html
<span></span>
```
Creates first line of the hamburger icon.

```html
<span></span>
```
Creates second line of the hamburger icon.

```html
<span></span>
```
Creates third line of the hamburger icon.

```html
</div>
```
Closes the hamburger div.

```html
</div>
```
Closes the container div.

```html
</nav>
```
Closes the navigation element.

```html
<section class="hero">
```
Creates a section element with class hero for the main banner area.

```html
<div class="hero-content">
```
Creates a div to hold the hero section content.

```html
<h2 id="greeting">Welcome to Savoury Bites</h2>
```
Creates a heading with ID greeting that JavaScript will update based on time of day.

```html
<p>Experience culinary excellence in every bite</p>
```
Creates a paragraph with the restaurant's tagline.

```html
<a href="menu.html" class="btn btn-primary">View Our Menu</a>
```
Creates a button-styled link to the menu page.

```html
</div>
```
Closes the hero-content div.

```html
</section>
```
Closes the hero section.

```html
<section class="about" id="about">
```
Creates a section for the about content with ID for direct linking.

```html
<div class="container">
```
Creates a container to center the about content.

```html
<h2 class="section-title">Our Story</h2>
```
Creates a heading for the about section with consistent styling.

```html
<div class="about-content">
```
Creates a div to hold the about text and image using flexbox.

```html
<div class="about-text">
```
Creates a div specifically for the text content.

```html
<p>Founded in 2020, Savoury Bites has been serving the community with passion and dedication. Our chef-driven menu features locally sourced ingredients and innovative culinary techniques that celebrate the rich flavors of South African cuisine.</p>
```
Creates a paragraph with the restaurant's founding story.

```html
<p>We believe in creating memorable dining experiences that bring people together. Every dish is crafted with love, attention to detail, and a commitment to excellence that you can taste in every bite.</p>
```
Creates another paragraph about the restaurant's philosophy.

```html
<p>Join us for an unforgettable culinary journey where tradition meets innovation, and every meal becomes a celebration.</p>
```
Creates a closing paragraph inviting customers.

```html
</div>
```
Closes the about-text div.

```html
<div class="about-image">
```
Creates a div for the about section image.

```html
<i class="fas fa-concierge-bell" style="font-size: 150px; color: var(--primary-color);"></i>
```
Adds a large decorative icon with inline styling for size and color.

```html
</div>
```
Closes the about-image div.

```html
</div>
```
Closes the about-content div.

```html
</div>
```
Closes the container div.

```html
</div>
```
Closes the about section.

```html
<footer class="footer">
```
Creates a footer element with class footer.

```html
<div class="container">
```
Creates a container for footer content.

```html
<div class="footer-content">
```
Creates a div to organize footer items in three columns.

```html
<div class="footer-section">
```
Creates first footer column for contact information.

```html
<h3>Contact Us</h3>
```
Creates heading for contact information.

```html
<p><i class="fas fa-map-marker-alt"></i> 123 Food Street, Cape Town, 8001</p>
```
Creates paragraph with location icon and address.

```html
<p><i class="fas fa-phone"></i> +27 21 123 4567</p>
```
Creates paragraph with phone icon and number.

```html
<p><i class="fas fa-envelope"></i> info@savourybites.co.za</p>
```
Creates paragraph with email icon and address.

```html
</div>
```
Closes first footer section.

```html
<div class="footer-section">
```
Creates second footer column for opening hours.

```html
<h3>Opening Hours</h3>
```
Creates heading for opening hours.

```html
<p>Monday - Friday: 11:00 AM - 10:00 PM</p>
```
Displays weekday hours.

```html
<p>Saturday - Sunday: 10:00 AM - 11:00 PM</p>
```
Displays weekend hours.

```html
</div>
```
Closes second footer section.

```html
<div class="footer-section">
```
Creates third footer column for social media links.

```html
<h3>Follow Us</h3>
```
Creates heading for social media.

```html
<div class="social-links">
```
Creates div to hold social media icons.

```html
<a href="#" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
```
Creates link with Facebook icon.

```html
<a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
```
Creates link with Instagram icon.

```html
<a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
```
Creates link with Twitter icon.

```html
</div>
```
Closes social-links div.

```html
</div>
```
Closes third footer section.

```html
</div>
```
Closes footer-content div.

```html
<div class="footer-bottom">
```
Creates div for copyright information at bottom of footer.

```html
<p>© 2025 Savoury Bites. All rights reserved. | Designed by Athini Zoleka</p>
```
Displays copyright text with current year.

```html
</div>
```
Closes footer-bottom div.

```html
</div>
```
Closes container div.

```html
</footer>
```
Closes footer element.

```html
<script src="js/script.js"></script>
```
Links the external JavaScript file for interactivity.

```html
</body>
```
Closes the body section.

```html
</html>
```
Closes the HTML document.