# specials.html - Line-by-Line Explanation

This file is the specials page for the Savoury Bites restaurant website. It displays current promotions and featured dishes with interactive elements.

## Document Declaration and Head Section

```html
<!DOCTYPE html>
```
Declares the document as HTML5, telling the browser which version of HTML to use.

```html
<html lang="en">
```
Opens the HTML document and sets the language to English for accessibility and SEO.

```html
<head>
```
Opens the head section where we put metadata and links to external files.

```html
<meta charset="UTF-8">
```
Sets character encoding to UTF-8 to support all characters and symbols.

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```
Makes the website responsive by setting the viewport to match device width.

```html
<meta name="description" content="Savoury Bites Specials - Check out our latest promotions and featured dishes">
```
Provides a description for search engines (SEO optimization).

```html
<meta name="keywords" content="restaurant specials, promotions, Savoury Bites deals, Cape Town dining">
```
Lists keywords related to the website for search engines.

```html
<title>Specials & Promotions | Savoury Bites</title>
```
Sets the title that appears in the browser tab.

```html
<link rel="stylesheet" href="css/styles.css">
```
Links the external CSS stylesheet to style the webpage.

```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```
Links Font Awesome library for icons (menu icons, social media icons, etc.).

```html
</head>
```
Closes the head section.

## Body Section

```html
<body>
```
Opens the body section where all visible content goes.

```html
<button id="darkModeToggle" class="dark-mode-btn" aria-label="Toggle Dark Mode">
```
Creates a button for dark mode toggle with unique ID for JavaScript control.

```html
<i class="fas fa-moon"></i>
```
Adds a moon icon from Font Awesome inside the dark mode button.

```html
</button>
```
Closes the button element.

```html
<nav class="navbar">
```
Creates a navigation element with class navbar for styling.

```html
<div class="container">
```
Creates a container div to center and constrain the navigation content.

```html
<div class="logo">
```
Creates a div to hold the restaurant logo and name.

```html
<i class="fas fa-utensils"></i>
```
Adds a utensils icon (fork and knife) as part of the logo.

```html
<h1>Savoury Bites</h1>
```
Creates the main heading with the restaurant name.

```html
</div>
```
Closes the logo div.

```html
<ul class="nav-menu">
```
Creates an unordered list for navigation menu items.

```html
<li><a href="index.html">Home</a></li>
```
Creates menu item linking to homepage.

```html
<li><a href="menu.html">Menu</a></li>
```
Creates menu item linking to the menu page.

```html
<li><a href="specials.html" class="active">Specials</a></li>
```
Creates menu item linking to the specials page with active class to highlight current page.

```html
<li><a href="reservation.html">Reservations</a></li>
```
Creates menu item linking to the reservation page.

```html
</ul>
```
Closes the navigation menu list.

```html
<div class="hamburger">
```
Creates a div for the mobile hamburger menu icon.

```html
<span></span>
```
Creates first line of the hamburger icon.

```html
<span></span>
```
Creates second line of the hamburger icon.

```html
<span></span>
```
Creates third line of the hamburger icon.

```html
</div>
```
Closes the hamburger div.

```html
</div>
```
Closes the container div.

```html
</nav>
```
Closes the navigation element.

```html
<section class="hero specials-hero">
```
Creates a section element with class hero for the specials page banner area.

```html
<div class="hero-content">
```
Creates a div to hold the hero section content.

```html
<h2>Special Offers & Promotions</h2>
```
Creates a heading for the specials page hero section.

```html
<p>Exclusive deals and featured dishes just for you</p>
```
Creates a paragraph with the specials page tagline.

```html
</div>
```
Closes the hero-content div.

```html
</section>
```
Closes the hero section.

```html
<section class="specials-section">
```
Creates a section for the specials content.

```html
<div class="container">
```
Creates a container to center the specials content.

```html
<h2 class="section-title">Current Specials</h2>
```
Creates a heading for the specials section with consistent styling.

## Special Offers

### Special Offer 1

```html
<div class="special-card">
```
Creates a div for the first special offer card.

```html
<div class="special-image">
```
Creates a div for the special offer image.

```html
<img src="https://res.cloudinary.com/dtzfw1kws/image/upload/v1761130269/christmas-wallpaper-2009590_640_dmg4l1.jpg" alt="Happy Hour Special">
```
Adds an image for the special offer.

```html
</div>
```
Closes the special-image div.

```html
<div class="special-content">
```
Creates a div for the special offer content.

```html
<h3>Happy Hour Every Day!</h3>
```
Creates a heading for the special offer name.

```html
<p class="special-description">Join us for Happy Hour Monday to Sunday from 4pm to 6pm. Enjoy 20% off all drinks and selected appetizers.</p>
```
Creates a paragraph with the special offer description.

```html
<div class="special-details">
```
Creates a div for special offer details.

```html
<span class="special-badge">Daily</span>
```
Creates a badge indicating the special is daily.

```html
<span class="special-time">4:00 PM - 6:00 PM</span>
```
Creates a span showing the special time.

```html
</div>
```
Closes the special-details div.

```html
<button class="btn btn-secondary special-modal-trigger" data-special="Happy Hour">View Details</button>
```
Creates a button that triggers a modal with details about the special.

```html
</div>
```
Closes the special-content div.

```html
</div>
```
Closes the special-card div.

### Special Offer 2 and 3

(Structure is the same as Special Offer 1 with different content)

## Featured Dishes Slider

```html
<section class="featured-dishes">
```
Creates a section for the featured dishes slider.

```html
<div class="container">
```
Creates a container to center the featured dishes content.

```html
<h2 class="section-title">Chef's Featured Dishes</h2>
```
Creates a heading for the featured dishes section.

```html
<div class="slider-container">
```
Creates a container for the slider.

```html
<div class="slider">
```
Creates the main slider element.

```html
<div class="slide">
```
Creates the first slide.

```html
<div class="dish-card">
```
Creates a card for the first dish.

```html
<div class="dish-image">
```
Creates a div for the dish image.

```html
<img src="https://res.cloudinary.com/dtzfw1kws/image/upload/v1761132127/platting-4282016_1280_1_der0hm.jpg" alt="Truffle Roast Chicken">
```
Adds an image for the dish.

```html
</div>
```
Closes the dish-image div.

```html
<div class="dish-info">
```
Creates a div for the dish information.

```html
<h3>Truffle Roast Chicken</h3>
```
Creates a heading for the dish name.

```html
<p>Herb-crusted chicken with truffle mashed potatoes and seasonal vegetables</p>
```
Creates a paragraph with the dish description.

```html
<div class="dish-price">R195</div>
```
Creates a div for the dish price.

```html
</div>
```
Closes the dish-info div.

```html
</div>
```
Closes the dish-card div.

```html
</div>
```
Closes the slide div.

### Additional Slides

(Second and third slides with the same structure but different content)

```html
<div class="slider-nav">
```
Creates a div for slider navigation buttons.

```html
<button class="slider-btn prev-btn"><i class="fas fa-chevron-left"></i></button>
```
Creates a previous button for the slider.

```html
<button class="slider-btn next-btn"><i class="fas fa-chevron-right"></i></button>
```
Creates a next button for the slider.

```html
</div>
```
Closes the slider-nav div.

```html
</div>
```
Closes the slider-container div.

```html
</div>
```
Closes the container div.

```html
</section>
```
Closes the featured-dishes section.

```html
<section class="reservation-cta">
```
Creates a call-to-action section for reservations.

(Contains the same CTA structure as menu.html)

## Specials Modal

```html
<div id="specialModal" class="modal">
```
Creates a modal div for special offer details.

```html
<div class="modal-content">
```
Creates a div for the modal content.

```html
<span class="close">&times;</span>
```
Creates a close button for the modal.

```html
<h2 id="modalTitle">Special Offer Details</h2>
```
Creates a heading for the modal title (updated by JavaScript).

```html
<div id="modalBody">
```
Creates a div for the modal body content (updated by JavaScript).

```html
<p>Special offer details will appear here.</p>
```
Creates placeholder text for the modal body.

```html
</div>
```
Closes the modalBody div.

```html
</div>
```
Closes the modal-content div.

```html
</div>
```
Closes the modal div.

```html
<footer class="footer">
```
Creates a footer element with class footer.

(Contains the same footer structure as index.html)

```html
<script src="js/script.js"></script>
```
Links the external JavaScript file for interactivity.

```html
</body>
```
Closes the body section.

```html
</html>
```
Closes the HTML document.