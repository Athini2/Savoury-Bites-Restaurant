# JavaScript Functionality Documentation

This document explains the JavaScript functionality implemented in the Savoury Bites website.

## Dark Mode Toggle

The dark mode feature allows users to switch between light and dark themes:

1. **Theme Detection**: Checks for saved user preference or OS preference
2. **Toggle Functionality**: Switches between themes when the button is clicked
3. **Persistence**: Saves user preference to localStorage
4. **Icon Change**: Updates the button icon between sun and moon

```javascript
// Check for saved theme preference or respect OS preference
const savedTheme = localStorage.getItem('theme');
const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');

// Toggle dark mode
darkModeToggle.addEventListener('click', function() {
    // Switch between themes and update localStorage
});
```

## Mobile Navigation

The mobile menu is implemented with a hamburger icon:

1. **Toggle Button**: Shows/hides navigation on small screens
2. **Auto-close**: Closes menu when a link is clicked
3. **CSS Transitions**: Smooth animation for menu appearance

```javascript
hamburger.addEventListener('click', function() {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});
```

## Dynamic Greeting

The homepage shows a personalized greeting based on the time of day:

1. **Time Detection**: Gets current hour with `new Date().getHours()`
2. **Message Selection**: Chooses appropriate greeting:
   - "Good Morning" (before 12 PM)
   - "Good Afternoon" (12 PM - 6 PM)
   - "Good Evening" (after 6 PM)

```javascript
const hours = new Date().getHours();
let greeting;

if (hours < 12) {
    greeting = "Good Morning! Welcome to Savoury Bites";
} else if (hours < 18) {
    greeting = "Good Afternoon! Welcome to Savoury Bites";
} else {
    greeting = "Good Evening! Welcome to Savoury Bites";
}
```

## Form Validation

The reservation form includes client-side validation:

1. **Required Fields**: Checks that all required fields are filled
2. **Email Format**: Validates email address format with regex
3. **Date Validation**: Ensures reservation date is not in the past
4. **User Feedback**: Shows alerts for validation errors
5. **Confirmation**: Displays success message after valid submission

```javascript
// Email validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!emailRegex.test(email)) {
    alert('Please enter a valid email address.');
    return;
}

// Date validation
const selectedDate = new Date(date);
const today = new Date();
today.setHours(0, 0, 0, 0);

if (selectedDate < today) {
    alert('Please select a future date for your reservation.');
    return;
}
```

## Image Slider

The featured dishes section includes an auto-rotating image slider:

1. **Auto-rotation**: Slides change automatically every 5 seconds
2. **Manual Navigation**: Previous/next buttons for user control
3. **Interval Reset**: Resets timer when user manually navigates
4. **Smooth Transitions**: CSS transitions for slide movement

```javascript
// Auto-advance slider every 5 seconds
function startSlider() {
    slideInterval = setInterval(() => {
        currentSlide = (currentSlide + 1) % slideCount;
        updateSlider();
    }, 5000);
}
```

## Modal Popups

Special offers are displayed in modal popups:

1. **Trigger Buttons**: Each special has a "View Details" button
2. **Dynamic Content**: Modal content changes based on which special is clicked
3. **Close Functionality**: Multiple ways to close the modal:
   - Close button (×)
   - Clicking outside the modal
4. **Smooth Animation**: CSS animation for modal appearance

```javascript
modalTriggers.forEach(trigger => {
    trigger.addEventListener('click', function() {
        // Update modal content based on data attribute
        const specialName = this.getAttribute('data-special');
        // Show modal with specific content
    });
});
```

## Smooth Scrolling

Navigation links with hash anchors have smooth scrolling:

1. **Event Listener**: Captures clicks on anchor links
2. **Position Calculation**: Determines target element position
3. **Animated Scroll**: Smooth scrolling to target section

```javascript
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        // Prevent default behavior and scroll smoothly
    });
});
```

## Utility Functions

Several helper functions support the main features:

1. **Email Validation**: Checks email format
2. **Phone Validation**: Validates South African phone numbers
3. **Currency Formatting**: Formats prices with currency symbol
4. **Date Handling**: Gets current date in required format

## Event Listeners

All JavaScript functionality is initialized when the DOM is fully loaded:

```javascript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all features
});
```

This ensures that all HTML elements are available before the JavaScript tries to interact with them.