# CSS Styles Documentation

This document explains the CSS styling approaches used in the Savoury Bites website.

## CSS Variables (Custom Properties)

The website uses CSS variables for consistent theming and easy maintenance:

```css
:root {
    --primary-color: #d4af37; /* Gold color for accents */
    --secondary-color: #8b0000; /* Deep red for highlights */
    --background-color: #fff; /* White background */
    --text-color: #333; /* Dark text */
    --light-bg: #f8f8f8; /* Light background for sections */
    --dark-bg: #1a1a1a; /* Dark background for footer */
    --border-color: #e0e0e0; /* Light border color */
    --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    --transition: all 0.3s ease;
}
```

Dark mode variables override these values:
```css
[data-theme="dark"] {
    --background-color: #121212;
    --text-color: #f0f0f0;
    --light-bg: #1e1e1e;
    --dark-bg: #000;
    --border-color: #333;
}
```

## Responsive Design

The website uses a mobile-first approach with media queries for different screen sizes:

1. **Base styles** work on mobile devices
2. **Tablet styles** (768px and above) modify layouts for medium screens
3. **Desktop styles** (992px and above) optimize for large screens

## Flexbox and Grid Layouts

The website uses modern CSS layout techniques:

- **Flexbox** for navigation, cards, and content sections
- **CSS Grid** for footer sections and form layouts

## Dark Mode Implementation

Dark mode is implemented using:
1. CSS custom properties that change values in dark mode
2. A toggle button that switches between themes
3. localStorage to remember user preference
4. OS preference detection as default

## Interactive Elements

The CSS includes styling for:
- Hover effects on buttons and links
- Smooth transitions for interactive elements
- Form styling with focus states
- Modal and slider components