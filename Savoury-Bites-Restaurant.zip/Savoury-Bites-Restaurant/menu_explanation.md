# menu.html - Line-by-Line Explanation

This file is the menu page for the Savoury Bites restaurant website. It displays the restaurant's offerings in categorized sections.

## Document Declaration and Head Section

```html
<!DOCTYPE html>
```
Declares the document as HTML5, telling the browser which version of HTML to use.

```html
<html lang="en">
```
Opens the HTML document and sets the language to English for accessibility and SEO.

```html
<head>
```
Opens the head section where we put metadata and links to external files.

```html
<meta charset="UTF-8">
```
Sets character encoding to UTF-8 to support all characters and symbols.

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```
Makes the website responsive by setting the viewport to match device width.

```html
<meta name="description" content="Savoury Bites Menu - Explore our delicious starters, mains, desserts and drinks">
```
Provides a description for search engines (SEO optimization).

```html
<meta name="keywords" content="restaurant menu, fine dining menu, Savoury Bites menu, Cape Town restaurant">
```
Lists keywords related to the website for search engines.

```html
<title>Our Menu | Savoury Bites</title>
```
Sets the title that appears in the browser tab.

```html
<link rel="stylesheet" href="css/styles.css">
```
Links the external CSS stylesheet to style the webpage.

```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```
Links Font Awesome library for icons (menu icons, social media icons, etc.).

```html
</head>
```
Closes the head section.

## Body Section

```html
<body>
```
Opens the body section where all visible content goes.

```html
<button id="darkModeToggle" class="dark-mode-btn" aria-label="Toggle Dark Mode">
```
Creates a button for dark mode toggle with unique ID for JavaScript control.

```html
<i class="fas fa-moon"></i>
```
Adds a moon icon from Font Awesome inside the dark mode button.

```html
</button>
```
Closes the button element.

```html
<nav class="navbar">
```
Creates a navigation element with class navbar for styling.

```html
<div class="container">
```
Creates a container div to center and constrain the navigation content.

```html
<div class="logo">
```
Creates a div to hold the restaurant logo and name.

```html
<i class="fas fa-utensils"></i>
```
Adds a utensils icon (fork and knife) as part of the logo.

```html
<h1>Savoury Bites</h1>
```
Creates the main heading with the restaurant name.

```html
</div>
```
Closes the logo div.

```html
<ul class="nav-menu">
```
Creates an unordered list for navigation menu items.

```html
<li><a href="index.html">Home</a></li>
```
Creates menu item linking to homepage.

```html
<li><a href="menu.html" class="active">Menu</a></li>
```
Creates menu item linking to the menu page with active class to highlight current page.

```html
<li><a href="specials.html">Specials</a></li>
```
Creates menu item linking to the specials page.

```html
<li><a href="reservation.html">Reservations</a></li>
```
Creates menu item linking to the reservation page.

```html
</ul>
```
Closes the navigation menu list.

```html
<div class="hamburger">
```
Creates a div for the mobile hamburger menu icon.

```html
<span></span>
```
Creates first line of the hamburger icon.

```html
<span></span>
```
Creates second line of the hamburger icon.

```html
<span></span>
```
Creates third line of the hamburger icon.

```html
</div>
```
Closes the hamburger div.

```html
</div>
```
Closes the container div.

```html
</nav>
```
Closes the navigation element.

```html
<section class="hero menu-hero">
```
Creates a section element with class hero for the menu page banner area.

```html
<div class="hero-content">
```
Creates a div to hold the hero section content.

```html
<h2>Our Culinary Creations</h2>
```
Creates a heading for the menu page hero section.

```html
<p>Handcrafted dishes made with passion and the finest ingredients</p>
```
Creates a paragraph with the menu page tagline.

```html
</div>
```
Closes the hero-content div.

```html
</section>
```
Closes the hero section.

```html
<section class="menu-section">
```
Creates a section for the menu content.

```html
<div class="container">
```
Creates a container to center the menu content.

```html
<h2 class="section-title">Delicious Menu</h2>
```
Creates a heading for the menu section with consistent styling.

## Menu Categories

### Starters Category

```html
<div class="menu-category">
```
Creates a div for the starters category.

```html
<h3 class="category-title">Starters</h3>
```
Creates a heading for the starters category.

```html
<div class="menu-items">
```
Creates a div to hold the starter menu items.

```html
<div class="menu-item">
```
Creates a div for the first starter item.

```html
<div class="item-info">
```
Creates a div for the item information.

```html
<h4>Truffle Arancini</h4>
```
Creates a heading for the dish name.

```html
<p>Crispy risotto balls with truffle oil and parmesan, served with marinara sauce</p>
```
Creates a paragraph with the dish description.

```html
</div>
```
Closes the item-info div.

```html
<div class="item-price">R85</div>
```
Creates a div for the item price.

```html
</div>
```
Closes the menu-item div.

```html
<div class="menu-item">
```
Creates a div for the second starter item.

```html
<div class="item-info">
```
Creates a div for the item information.

```html
<h4>Calamari Fritti</h4>
```
Creates a heading for the dish name.

```html
<p>Tender squid rings lightly fried and served with lemon aioli and chilli jam</p>
```
Creates a paragraph with the dish description.

```html
</div>
```
Closes the item-info div.

```html
<div class="item-price">R95</div>
```
Creates a div for the item price.

```html
</div>
```
Closes the menu-item div.

```html
<div class="menu-item">
```
Creates a div for the third starter item.

```html
<div class="item-info">
```
Creates a div for the item information.

```html
<h4>Beetroot Carpaccio</h4>
```
Creates a heading for the dish name.

```html
<p>Thinly sliced roasted beetroot with goat cheese mousse and candied walnuts</p>
```
Creates a paragraph with the dish description.

```html
</div>
```
Closes the item-info div.

```html
<div class="item-price">R75</div>
```
Creates a div for the item price.

```html
</div>
```
Closes the menu-item div.

```html
</div>
```
Closes the menu-items div.

```html
</div>
```
Closes the menu-category div.

### Main Courses Category

```html
<div class="menu-category">
```
Creates a div for the mains category.

```html
<h3 class="category-title">Main Courses</h3>
```
Creates a heading for the mains category.

```html
<div class="menu-items">
```
Creates a div to hold the main course menu items.

(Three menu items with the same structure as starters)

```html
</div>
```
Closes the menu-items div.

```html
</div>
```
Closes the menu-category div.

### Desserts Category

```html
<div class="menu-category">
```
Creates a div for the desserts category.

```html
<h3 class="category-title">Desserts</h3>
```
Creates a heading for the desserts category.

```html
<div class="menu-items">
```
Creates a div to hold the dessert menu items.

(Three menu items with the same structure as starters)

```html
</div>
```
Closes the menu-items div.

```html
</div>
```
Closes the menu-category div.

### Drinks Category

```html
<div class="menu-category">
```
Creates a div for the drinks category.

```html
<h3 class="category-title">Drinks</h3>
```
Creates a heading for the drinks category.

```html
<div class="menu-items">
```
Creates a div to hold the drink menu items.

(Three menu items with the same structure as starters)

```html
</div>
```
Closes the menu-items div.

```html
</div>
```
Closes the menu-category div.

```html
</div>
```
Closes the container div.

```html
</section>
```
Closes the menu-section.

```html
<section class="reservation-cta">
```
Creates a call-to-action section for reservations.

```html
<div class="container">
```
Creates a container to center the CTA content.

```html
<h3>Ready to Experience Our Cuisine?</h3>
```
Creates a heading for the CTA.

```html
<p>Make a reservation today and let us create a memorable dining experience for you.</p>
```
Creates a paragraph with the CTA text.

```html
<a href="reservation.html" class="btn btn-primary">Make a Reservation</a>
```
Creates a button-styled link to the reservation page.

```html
</div>
```
Closes the container div.

```html
</section>
```
Closes the reservation-cta section.

```html
<footer class="footer">
```
Creates a footer element with class footer.

(Contains the same footer structure as index.html)

```html
<script src="js/script.js"></script>
```
Links the external JavaScript file for interactivity.

```html
</body>
```
Closes the body section.

```html
</html>
```
Closes the HTML document.